'use client';

export default function HomePage() {
  return (
    <section className="bg-black h-full w-full">
    </section>
  );
}
